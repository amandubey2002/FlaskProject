from flask import Blueprint

rest_blueprint = Blueprint('rest_blueprint',__name__,url_prefix='/rest')