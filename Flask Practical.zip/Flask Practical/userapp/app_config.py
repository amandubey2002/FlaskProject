from flask import Flask

app = Flask(
    __name__,
    template_folder="/home/simprosys-aman/Aman/Flask/Flask Practical/Flask_APP/templates",
)