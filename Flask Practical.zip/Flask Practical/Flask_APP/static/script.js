function confirmDelete() {
    var result = confirm("Are you sure you want to delete this product?");
    if (result) {
        return true;
    } else {
        return false;
    }
}



  