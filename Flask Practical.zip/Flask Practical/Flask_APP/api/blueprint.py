from flask import Blueprint
blueprint = Blueprint('blueprint',__name__,url_prefix='/api')

