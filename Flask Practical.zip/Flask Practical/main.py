from userapp.api import user_blueprint
from userapp.app_config import app
from restapi.blueprint import rest_blueprint
from product_app.blueprint import product_blueprint

app.register_blueprint(user_blueprint)
app.register_blueprint(rest_blueprint)
app.register_blueprint(product_blueprint)


if __name__ == '__main__':
    app.run(debug=True,port=8000)