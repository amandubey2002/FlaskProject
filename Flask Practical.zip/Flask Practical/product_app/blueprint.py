from flask import Blueprint

product_blueprint = Blueprint('product_blueprint',__name__,url_prefix='/product')